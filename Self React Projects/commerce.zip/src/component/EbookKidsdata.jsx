import kidsbox1 from "../assets/Images/kidsbox1.jpg"
import kidsbox2 from "../assets/Images/kidsbox2.jpg"
import kidsbox3 from "../assets/Images/kidsbox3.jpg"
import kidsbox4 from "../assets/Images/kidsbox4.jpg"
import kidsbox5 from "../assets/Images/kidsbox5.jpg"


export const ebookkids = [
    {
        img:kidsbox1,
        heading:"Research for beginners",
        price:"Free",
    },
    {
        img:kidsbox2,
        heading:"You too win",
        price:"$30",
    },
    {
        img:kidsbox3,
        heading:"Python learning for beginners",
        price:"$30",
    },
    {
        img:kidsbox4,
        heading:"Advanced Learning for robotics",
        price:"$29",
    },
    {
        img:kidsbox5,
        heading:"Web Design for Web Developers",
        price:"$35",
    },
    {
        heading:"A House Between Earth and the Moon",
        price:"Free",
    },
]