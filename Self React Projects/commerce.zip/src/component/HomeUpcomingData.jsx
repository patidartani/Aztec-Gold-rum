import upcomingcard1 from "../assets/Images/upcomingcard1.jpg"
import upcomingcard2 from "../assets/Images/upcomingcard2.jpg"
import upcomingcard3 from "../assets/Images/upcomingcard3.jpg"
import upcomingcard4 from "../assets/Images/upcomingcard4.jpg"
import upcomingcard5 from "../assets/Images/upcomingcard5.jpg"
import upcomingcard6 from "../assets/Images/upcomingcard6.jpg"
export const upcomingdata = [
    {
        img: upcomingcard1,
        heading: "Color Theory for Designers",
        para: "Blog Masterclass: How To Build A Successful",
    },
    {
        img: upcomingcard2,
        heading: "Blog Masterclass: How To Build A Successful",
        para: "Let go of self-doubt, embrace optimism, and...",
    },
    {
        img: upcomingcard3,
        heading: "Customer Service English Essentials",
        para: "Contrary to papular belief Learn Ipsum is not simply...",
    },
    {
        img: upcomingcard4,
        heading: "Customer Service English Essentials",
        para: "Contrary to papular belief Learn Ipsum is not simply...",
    },
    {
        img: upcomingcard5,
        heading: "Ultimate Guide to Running",
        para: "Contrary to popular belief Lorem Ipsum in not simply",
    },
    {
        img: upcomingcard6,
        heading: "Complete Figma Mega course: UI/UX Design",
        para: "Contrary to popular belief Lorem Ipsum in not simply",
    },

]