import topcourse1 from "../assets/Images/topcourse1.webp"
import topcourse2 from "../assets/Images/topcourse2.webp"
import topcourse3 from "../assets/Images/topcourse3.webp"
import topcourse4 from "../assets/Images/topcourse4.webp"
import topcourse5 from "../assets/Images/topcourse5.webp"
import topcourse6 from "../assets/Images/topcourse6.webp"
import topcourse7 from "../assets/Images/topcourse7.jpg"
export const gallery = [
    {
        img:topcourse1,
        para:"Lorem ipsum dolor sit amet consectetur adipisicing sit amet consectetur adipisicing elit. Aliquid, perspiciatis?",

    },
    {
        img:topcourse2,
        para:"Lorem ipsum dolor sit amet consectetur adipisicing sit amet consectetur adipisicing elit. Aliquid, perspiciatis?",

    },
    {
        img:topcourse3,
        para:"Lorem ipsum dolor sit amet consectetur sit amet consectetur adipisicing adipisicing elit. Aliquid, perspiciatis?",

    },
    {
        img:topcourse4,
        para:"Lorem ipsum dolor sit amet consectetur adipisicing sit amet consectetur adipisicing elit. Aliquid, perspiciatis?",

    },
    {
        img:topcourse5,
        para:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, sit amet consectetur adipisicing perspiciatis?",

    },
    {
        img:topcourse6,
        para:"Lorem ipsum dolor sit amet sit amet consectetur adipisicing consectetur adipisicing elit. Aliquid, perspiciatis?",

    },
    {
        img:topcourse7,
        para:"Lorem ipsum dolor sit amet sit amet consectetur adipisicing consectetur adipisicing elit. Aliquid, perspiciatis?",

    },
   
]