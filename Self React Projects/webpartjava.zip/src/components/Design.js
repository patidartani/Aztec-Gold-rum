import React from 'react'

export default function Design() {
  return (
    <>
    <div className="aboutcontainer1">
        <div className="aboutleft">
           <div className="aboutcontent">
           <h2>photo editing</h2>
            <span>Staurants in the country. This is the place where food meets passion creating the culinary masterpieces that are sure to enchant</span>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tempus molestie ligula mattis imperdiet. Quisque vitae erat diam. Cras congue pellentesque imperdiet. Phasellus velit tellus. Quisque vitae erat diam. Cras congue pellentesque imperdiet. Nulla tempus molestie ligula mattis imperdiet.</p>
           </div>
        </div>
        <div className="aboutright"></div>
    </div>
    </>
  )
}
