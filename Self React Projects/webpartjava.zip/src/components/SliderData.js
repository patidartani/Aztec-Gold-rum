export const gallery = [
    {
        url: "https://solene.qodeinteractive.com/wp-content/uploads/2019/12/h1-slider-img-3.new_.jpg",
        title: "MADE TO SHINE",
        name:"Rocking Star",
        place:"132-A,Indrapuri Bhopal",
        desc:"Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam, mollitia",
        button:"REGISTER",
        href:"/salsa",

    },
    {
        url: "https://i0.wp.com/atozmomm.com/wp-content/uploads/2021/01/adrianna-van-groningen-0gld1ssks0c-unsplash.jpg?fit=685%2C457&ssl=1",
        title: "MADE FOR YOU",
        name:"Rocking Star",
        place:"132-A,Indrapuri Bhopal",
        desc:"Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam, mollitia",
        button:"VIEW MORE",
        href:"/Music",

    },
    {
        url: "https://solene.qodeinteractive.com/wp-content/uploads/2020/01/h1-slider-img-1.jpg",
        title: "MADE WITH LOVE",
       
        desc:"Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam, mollitia",
        button:"SHOW LIVE",
      

    },
    
]

