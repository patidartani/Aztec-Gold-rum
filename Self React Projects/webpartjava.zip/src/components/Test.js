import React from 'react'

export default function Test() {
    return (
        <>

            <div className="container4">
                <div className="heading4">
                    <h2>testimonials</h2>
                </div>
                <div className="lastp">
                    <div className="para">
                        <p>Accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi at vero eos et vitae feugiat magna, ut ligula Accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi at vero eos et vitae feugiat magna, ut ligula</p>
                    </div>
                </div>
            </div>
        </>
    )
}
