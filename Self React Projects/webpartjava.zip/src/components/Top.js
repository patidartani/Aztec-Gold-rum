import React from 'react'

export default function Top() {
  return (
    <>
      <div className="topmain">
        <div className="topimage">
            <div className="toptxt"><h1>about us</h1></div>
        </div>
      </div>
    </>
  )
}

